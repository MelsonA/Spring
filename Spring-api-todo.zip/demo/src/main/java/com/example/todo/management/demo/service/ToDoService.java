package com.example.todo.management.demo.service;

import com.example.todo.management.demo.dto.ToDoDto;

import java.util.List;

public interface ToDoService {

    ToDoDto createToDo(ToDoDto toDoDto);
    ToDoDto getToDo(Long id);
    List<ToDoDto> getAllToDo();
    ToDoDto updateToDo(ToDoDto toDoDto,Long id);
    void deleteToDo(Long id);
    ToDoDto completeToDo(Long id);
    ToDoDto incompleteToDo(Long id);

}
