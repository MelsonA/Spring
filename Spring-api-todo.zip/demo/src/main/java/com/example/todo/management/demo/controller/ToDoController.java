package com.example.todo.management.demo.controller;

import com.example.todo.management.demo.dto.LoginDto;
import com.example.todo.management.demo.dto.ToDoDto;
import com.example.todo.management.demo.service.JwtService;
import com.example.todo.management.demo.service.ToDoService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@AllArgsConstructor
@RequestMapping("/api/todos")
public class ToDoController {
    private ToDoService toDoService;
    private AuthenticationManager authenticationManager;
    private JwtService jwtService;
    @PostMapping("login")
    public ResponseEntity<String> addLogin(@RequestBody LoginDto loginDto){
        UsernamePasswordAuthenticationToken token
                = new UsernamePasswordAuthenticationToken(loginDto.getUsername(),loginDto.getPassword());
        authenticationManager.authenticate(token);
        String jwt = jwtService.generate(loginDto.getUsername());
        return new ResponseEntity<>(jwt,HttpStatus.OK);
    }
    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping
    public ResponseEntity<ToDoDto> addToDo(@RequestBody ToDoDto toDoDto){
        ToDoDto saveToDo=toDoService.createToDo(toDoDto);
        return new ResponseEntity<>(saveToDo, HttpStatus.CREATED);
    }

    @GetMapping("{id}")
    public ResponseEntity<ToDoDto> getToDo(@PathVariable ("id") Long id){
        ToDoDto getToDos=toDoService.getToDo(id);
        return new ResponseEntity<>(getToDos, HttpStatus.OK);
    }

    @GetMapping
    public ResponseEntity<List<ToDoDto>> getAllToDo(ToDoDto toDoDto){
        List<ToDoDto> allToDo=toDoService.getAllToDo();
        return new ResponseEntity<>(allToDo,HttpStatus.OK);
    }

    @PutMapping("{id}")
    public ResponseEntity<ToDoDto> updateToDo(@PathVariable("id") Long id, @RequestBody ToDoDto toDoDto){
        toDoDto.setId(id);
        ToDoDto updatedToDo=toDoService.updateToDo(toDoDto,id);
        return new ResponseEntity<>(updatedToDo,HttpStatus.OK);
    }

    @DeleteMapping("{id}")
    public ResponseEntity<String> deleteToDo(@PathVariable ("id") Long id){
        toDoService.deleteToDo(id);
        return new ResponseEntity<>("Todo Deleted", HttpStatus.NO_CONTENT);
    }

    @PatchMapping("{id}/complete")
    public ResponseEntity<ToDoDto> completeToDo(@PathVariable ("id") Long id){
        ToDoDto completedToDo=toDoService.completeToDo(id);
        return new ResponseEntity<>(completedToDo, HttpStatus.NO_CONTENT);
    }

    @PatchMapping("{id}/incomplete")
    public ResponseEntity<ToDoDto> incompleteToDo(@PathVariable ("id") Long id){
        ToDoDto inCompletedToDo=toDoService.incompleteToDo(id);
        return new ResponseEntity<>(inCompletedToDo, HttpStatus.NO_CONTENT);
    }
}
