package com.example.todo.management.demo.repository;

import com.example.todo.management.demo.entity.ToDo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TodoRepository extends JpaRepository<ToDo,Long> {
}
