package com.example.todo.management.demo.repository;

import com.example.todo.management.demo.entity.Role;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepository extends JpaRepository<Role,Long> {
}
