package com.example.todo.management.demo.service.impl;

import com.example.todo.management.demo.dto.ToDoDto;
import com.example.todo.management.demo.entity.ToDo;
import com.example.todo.management.demo.exception.ResourceNotFoundException;
import com.example.todo.management.demo.repository.TodoRepository;
import com.example.todo.management.demo.service.ToDoService;
import lombok.AllArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import java.lang.module.ResolutionException;
import java.util.List;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class ToDoServiceImpl implements ToDoService {

    private TodoRepository todoRepository;
    private ModelMapper modelMapper;
    @Override
    public ToDoDto createToDo(ToDoDto toDoDto) {
       ToDo toDo =modelMapper.map(toDoDto,ToDo.class);
       ToDo createdToDo=todoRepository.save(toDo);
        return modelMapper.map(createdToDo,ToDoDto.class);
    }

    @Override
    public ToDoDto getToDo(Long id) {
        ToDo todo = todoRepository.findById(id)
                .orElseThrow(()-> new ResolutionException("ToDo not found with id:"+id));
        return modelMapper.map(todo, ToDoDto.class);
    }

    @Override
    public List<ToDoDto> getAllToDo() {
        List<ToDo> toDos=todoRepository.findAll();
        List<ToDoDto> listToDo=toDos.stream()
                .map((todo)->modelMapper.map(todo,ToDoDto.class)).collect(Collectors.toList());
        return listToDo;
    }

    @Override
    public ToDoDto updateToDo(ToDoDto toDoDto,Long id) {
        ToDo todo =modelMapper.map(toDoDto,ToDo.class);
        ToDo todo1=todoRepository.findById(todo.getId())
                .orElseThrow(()-> new ResourceNotFoundException("ToDo not found with id:"+todo.getId()));
        todo1.setTitle(toDoDto.getTitle());
        todo1.setDescription(toDoDto.getDescription());
        todo1.setCompleted(toDoDto.getCompleted());
        ToDo updatedToDo=todoRepository.save(todo1);
        return modelMapper.map(updatedToDo,ToDoDto.class);
    }

    @Override
    public void deleteToDo(Long id) {
        ToDo todo = todoRepository.findById(id)
                .orElseThrow(()-> new ResolutionException("ToDo not found with id:"+id));
        todoRepository.deleteById(id);
    }

    @Override
    public ToDoDto completeToDo(Long id) {
        ToDo todo=todoRepository.findById(id)
                .orElseThrow(()-> new ResourceNotFoundException("ToDo not found with id:"+id));
        todo.setCompleted(true);
        ToDo updatedToDo=todoRepository.save(todo);
        return modelMapper.map(updatedToDo,ToDoDto.class);
    }

    @Override
    public ToDoDto incompleteToDo(Long id) {
        ToDo todo=todoRepository.findById(id)
                .orElseThrow(()-> new ResourceNotFoundException("ToDo not found with id:"+id));
        todo.setCompleted(false);
        ToDo updatedToDo=todoRepository.save(todo);
        return modelMapper.map(updatedToDo,ToDoDto.class);
    }
}
