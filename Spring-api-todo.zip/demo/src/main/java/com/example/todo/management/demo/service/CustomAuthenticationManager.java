package com.example.todo.management.demo.service;

import com.example.todo.management.demo.entity.User;
import com.example.todo.management.demo.repository.UserRepository;
import lombok.AllArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
public class CustomAuthenticationManager implements AuthenticationManager {
    private UserRepository userRepository;
    private PasswordEncoder passwordEncoder;


    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        String username=authentication.getName();
        String password=authentication.getCredentials().toString();
        if(isValidation(username,password)){
            return new UsernamePasswordAuthenticationToken(username,password);
        }else {
            throw new AuthenticationException("Invalid Credentials") {
            };
        }

    }

    public boolean isValidation(String username,String password){
        User user=userRepository.findByUserName(username)
                .orElseThrow(()->new UsernameNotFoundException("User Not Found"));
        boolean usernameEqual = user.getUserName().equals(username);
        boolean passwordEqual= passwordEncoder.matches(password,user.getPassword());
        return usernameEqual && passwordEqual;
    }
}
