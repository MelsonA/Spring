package com.example.todo.management.demo.service;

import com.example.todo.management.demo.entity.User;
import com.example.todo.management.demo.repository.UserRepository;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.AllArgsConstructor;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.web.authentication.WebAuthenticationDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Service;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.Set;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class JwtTokenFilter extends OncePerRequestFilter {
    private JwtService jwtService;
    private UserRepository userRepository;
    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
       String authorizationHeader= request.getHeader("Authorization");

       if(authorizationHeader == null || authorizationHeader.isEmpty() || !authorizationHeader.startsWith("Bearer")){
           filterChain.doFilter(request,response);
           return;
       }

       String token = authorizationHeader.split(" ")[1];
        if(!jwtService.validate(token)){
            filterChain.doFilter(request,response);
            return;
        }

        String username= jwtService.getUserName(token);
        User user=userRepository.findByUserName(username).
                orElseThrow(()-> new UsernameNotFoundException("User not found"));

        Set<GrantedAuthority> authorities=user.getRoles().stream().map((roles)-> new SimpleGrantedAuthority(roles.getName()))
                .collect(Collectors.toSet());

        UsernamePasswordAuthenticationToken _token= new UsernamePasswordAuthenticationToken(
                username,user.getPassword(),authorities);
        _token.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));

        SecurityContextHolder.getContext().setAuthentication(_token);
        filterChain.doFilter(request,response);
    }
}
